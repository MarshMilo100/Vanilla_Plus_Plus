MOD COMPATS CREDITS

- Aileron by Egshels/Team Lodestar
- Allurement by Team Abnormals
- Apotheosis by Shadows_of_Fire
- Ars Elemental by Alexth99
- Ars Nouveau by baileyholl2
- Backpacked by MrCrayfish
- Better End by Quiqueck
- Better Nether by Quiqueck
- Combat Enchantments by dsfhdshdjtsb
- Combat Roll by daedelus_dev
- Create by Simibubi
- Create: Garnished by DakotaPrideModding
- Create Stuff 'N Additions by Furti_Two
- Deeper and Darker by KyaniteMods
- Dungeons and Taverns by Nova_Wostra
- Eleron by Soumeh
- Enchancement by MoriyaShiine
- Expanded Combat by Userofbricks
- Farmer's Delight by Vectorwing
- Forbidden and Arcanus by cesar_zorak
- Galosphere by orcinus73
- Guarding by ExDrill
- Incantationem by Luligabi12/CafeteriaGuild
- Mo' Enchantments by geosava
- My Nether's Delight by soytutta
- Origins by Apace100
- Passable Foliage by Snownee
- Piglin Proliferation by almightytallestred
- Simple Spears by icandoodle
- Soul Bound Enchantment by imoonday1008
- Soul fire'd by CrystalSpider
- Supplementaries by MehVahdJukaar
- Tactical Shield Overhaul by someaddon
- The Bumblezone by telepathicgrunt
- The Twilight Forest by Benimatic
- The Undergarden by Quek04
- Vein Mining by TheIllusiveC4
- Wizards (RPG Series) by daedelus_dev 

PLEASE SUPPORT THE ORIGINAL MODS AND THEIR AUTHORS!

* OptiFine, Forge CIT, CIT Resewn, or another mod that supports the MCPatcher format must be installed for this pack to work correctly

PERMISSIONS AND CREDITS

Terms of Use
- DO NOT use any textures featured in this pack in a published or otherwise distributed project
- DO NOT redistribute this pack or post on ANY external website!!
 * only legit downloads are on Curseforge, Modrinth, and Planet Minecraft posted by PareidoliaG
- DO NOT change or modify this pack and repost without permission
- You CAN use this texture pack in a modpack
- You CAN use these textures in a PERSONAL USE ONLY pack

Texture Credits
- Credits for all textures go to PareidoliaG
- Textures are based on Minecraft book texture by Jappa
- Some textures use palettes/design ideas from the listed mods and vanilla