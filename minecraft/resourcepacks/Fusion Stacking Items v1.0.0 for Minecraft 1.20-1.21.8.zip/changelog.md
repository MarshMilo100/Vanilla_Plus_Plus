### Fusion Stacking Items 1.0.0
- Initial release of Fusion Stacking Items
